export const breakpoints = {
  xs: 320,
  s: 480,
  m: 734,
  l: 1068,
  xl: 1440,
  "page-max": 1660,
};
