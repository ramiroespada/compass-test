import React from 'react';

export const Headline = (props: { label:String}) => {
  return <h1>{props.label}</h1>;
};
